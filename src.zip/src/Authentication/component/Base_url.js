import React from "react";
const Base_url = "https://mynt-dev.webmavericks.org";

export default Base_url;