const Data =
[
    {
        key : "1",
        imgsrc : "https://png.pngtree.com/png-clipart/20220909/original/pngtree-investment-icon-illustration-png-image_8494132.png ",
        title : "Mildcares-Gynocup",
        txt : "We at Mildcares strive to empower womanhood! By building high-Quality hygiene and personal care products our... ",
    },
    {
        key : "2",
        imgsrc : "https://w7.pngwing.com/pngs/283/598/png-transparent-return-on-investment-rate-of-return-investment-company-others-miscellaneous-company-service-thumbnail.png",
        title : "Mildcares-Gynocup",
        txt : "Settl. is a technology- driven accommodation platform focused on providing a convenient and high-quality living expe...",
    },
    {
        key : "3",
        imgsrc:"https://png.pngtree.com/png-clipart/20220909/original/pngtree-investment-icon-illustration-png-image_8494132.png ",
        title : "Mildcares-Gynocup",
        txt : "We at Mildcares strive to empower womanhood! By building high-Quality hygiene and personal care products our...",
    },
]
export default Data;